import React from 'react';
import Preloader from '@/app/components/Preloader';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/app/components/HeroSection';
import HeroBridge from '@/app/components/HeroBridge';
// import ProblemSection from '@/app/components/ProblemSection';
import ServicesSection from '@/app/components/ServicesSection';
import ProcessSection from '@/app/components/ProcessSection';
import TransformationSection from '@/app/components/TransformationSection';
import ShowcaseSection from '@/app/components/ShowcaseSection';
{/*import FloatingTestimonialsSection from '@/app/components/FloatingTestimonialsSection'; */}
import TestimonialsSection from '@/app/components/TestimonialsSection';
import FAQSection from '@/app/components/FAQSection';
import CTASection from '@/app/components/CTASection';
import ScrollAnimationInit from '@/app/components/ScrollAnimationInit';

export default function HomePage() {
  return (
    <main data-page-shell="home" className="relative bg-background [overflow-x:clip]">
      <Preloader />
      <ScrollAnimationInit />
      <Header />

      {/* 1. Hero — cinematic entry */}
      <HeroSection />

      {/* Bridge: hero bleeds into next section with descending particles */}
      <HeroBridge />

      {/* 2. Problem — glitch / uneasy / frustration 
      <ProblemSection />*/}

      {/* 3. Services — the solution revealed */}
      <ServicesSection />


      <ShowcaseSection />

      {/* 4. Process — clarity / structure / sticky storytelling */}
      <ProcessSection />

      {/* 5. Showcase — premium auto-scroll with 3D tilt + depth */}
      

      {/* 6. Transformation — before vs after, the upgrade */}
      <TransformationSection />

      {/* 7. Testimonials — floating, drifting, alive social proof
      <FloatingTestimonialsSection /> */}

      {/* 7b. Testimonials redesigned — marquee editorial rows */}
      <TestimonialsSection />

      {/* 7c. FAQ — collapsible two-column, single viewport */}
      <FAQSection />

      {/* 8. CTA */}
      <CTASection />

      <Footer />
    </main>
  );
}
